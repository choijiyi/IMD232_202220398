let traffic;
// traffic이라는 이름의 변수 선언
let infiniteOffset = 80;

function setup() {
  // 프로그램 실행시 단 한번 호출된다. 화면 크기나 배경색 등의 초기환경 요소를 정의한다.
  setCanvasContainer('canvas', 3, 2, true);
  // 캔버스를 canvas라는 id가 있는 위치에 3대 2의 비율로 생성한다.
  colorMode(HSL, 360, 100, 100, 100);
  background('white');
  // 배경색을 흰색으로 하겠다.
  traffic = new Traffic();
  for (let n = 0; n < 10; n++) {
    traffic.addVehicle(random(width), random(height));
  }
}

function draw() {
  // setup함수 직후에 호출된다. 프로그램 실행이 중단되거나 noLoop함수가 호출되기 전까지 블록 내에 포함된 코드들을 계속 실행한다.
  background('white');
  // 배경생을 흰색으로 하겠다.
  traffic.run();
}

function mouseDragged() {
  traffic.addVehicle(mouseX, mouseY);
}
